<h1>Lista de veiculos</h1>
<a href="{{ route('veiculos.create') }}">Adicionar Veículo</a>
<ul>
    @foreach($veiculos as $veiculo)
        <li>{{ $veiculo->user }} ({{ $veiculo->matricula }})
            <a href="{{ route('veiculos.edit', $veiculo->id) }}">Editar</a>
            <form action="{{ route('veiculos.destroy', $veiculo->id) }}" method="POST">
                @csrf
                @method('DELETE')
                <button type="submit">Deletar</button>
            </form>
        </li>
    @endforeach
</ul>
