<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ClienteController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $clientes = ClientesController::all();
        return view('clientes.index', compact('clientes'));
    }
    
    public function create()
    {
        return view('clientes.create');
    }
    
    public function store(Request $request)
    {
        ClientesController::create($request->all());
        return redirect()->route('clientes.index');
    }
    
    public function edit($id)
    {
        $cliente = ClientesController::find($id);
        return view('clientes.edit', compact('cliente'));
    }
    
    public function update(Request $request, $id)
    {
        $cliente = Cliente::find($id);
        $cliente->update($request->all());
        return redirect()->route('clientes.index');
    }
    
    public function destroy($id)
    {
        Cliente::destroy($id);
        return redirect()->route('clientes.index');
    }
}
