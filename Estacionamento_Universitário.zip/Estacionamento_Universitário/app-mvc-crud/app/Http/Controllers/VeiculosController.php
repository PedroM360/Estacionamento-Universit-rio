<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ClientesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $veiculos = Cliente::all();
        return view('veiculos.index', compact('veiculos'));
    }
    
    public function create()
    {
        return view('veiculos.create');
    }
    
    public function store(Request $request)
    {
        Cliente::create($request->all());
        return redirect()->route('veiculos.index');
    }
    
    public function edit($id)
    {
        $veiculo = Cliente::find($id);
        return view('veiculos.edit', compact('veiculo'));
    }
    
    public function update(Request $request, $id)
    {
        $veiculo = Cliente::find($id);
        $veiculo->update($request->all());
        return redirect()->route('veiculos.index');
    }
    
    public function destroy($id)
    {
        Cliente::destroy($id);
        return redirect()->route('veiculos.index');
    }
    
}
